#include "graph.h"
#include "heap.h"
#include <limits>

class DijkstraSp
{

public:
    DijkstraSp(int vNum)
    {
        num = vNum;
        edgeTo = new EdgeNode[vNum];
        distTo = new double[vNum];
        pq.init(vNum);
        for (int v = 0; v < vNum; v++)
        {
            distTo[v] = (numeric_limits<double>::max)();
        }
    }
    void init(Graph* G, int s);
    void relax(Graph* G,int v);
    double queryDistTo(int v)
    {
        return distTo[v];
    }
    bool hassPathTo(int v)
    {
        return distTo[v] < (numeric_limits<double>::max)();
    }
    void toString()
    {
        for (int i = 0; i < num; i++)
        {
            cout << distTo[i] << ",";
        }
    }
    ~DijkstraSp()
    {
        delete[] edgeTo;
        delete[] distTo;
    }

private:
    int num;
    IndexMinPQ pq;
    EdgeNode *edgeTo;
    double *distTo;
};